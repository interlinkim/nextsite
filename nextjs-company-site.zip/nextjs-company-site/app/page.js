'use client'
import { motion, AnimatePresence } from 'framer-motion'
import { useEffect, useState } from 'react'

const palabras = ["Innovación", "Calidad", "Eficiencia", "Confianza"]

export default function Home() {
  const [index, setIndex] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setIndex((prev) => (prev + 1) % palabras.length)
    }, 2500)
    return () => clearInterval(interval)
  }, [])

  return (
    <main className="flex flex-col items-center justify-center min-h-screen bg-gray-50 p-8 text-center">
      <h1 className="text-4xl font-bold mb-6">
        Ofrecemos{" "}
        <span className="relative inline-block w-40 h-12 overflow-hidden align-middle">
          <AnimatePresence mode="wait">
            <motion.span
              key={palabras[index]}
              initial={{ y: 40, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -40, opacity: 0 }}
              transition={{ duration: 0.6 }}
              className="absolute left-0 right-0 text-blue-600"
            >
              {palabras[index]}
            </motion.span>
          </AnimatePresence>
        </span>
      </h1>

      <section className="max-w-2xl mb-12">
        <h2 className="text-2xl font-semibold mb-4">Quiénes somos</h2>
        <p className="text-gray-700 leading-relaxed">
          Somos una empresa que nació con la visión de transformar la manera en que nuestros clientes acceden a soluciones tecnológicas. 
          Creemos en el poder de la innovación aplicada con propósito y en la construcción de relaciones basadas en la confianza. 
          Nuestro equipo combina experiencia y pasión para ofrecer servicios que no solo cumplen, sino superan las expectativas. 
          Aquí, cada proyecto es una oportunidad para crecer junto a quienes confían en nosotros.
        </p>
      </section>

      <section className="grid md:grid-cols-2 gap-6 max-w-4xl">
        {[
          { titulo: "Asesoría Estratégica", desc: "Impulsamos tu negocio con planes a medida." },
          { titulo: "Desarrollo Web", desc: "Creamos experiencias digitales modernas y escalables." },
          { titulo: "Transformación Digital", desc: "Digitalizamos procesos para mayor eficiencia." },
          { titulo: "Soporte Técnico", desc: "Siempre cerca para resolver tus necesidades." }
        ].map((serv, i) => (
          <div key={i} className="bg-white p-6 rounded-2xl shadow hover:shadow-lg transition">
            <h3 className="text-xl font-semibold mb-2">{serv.titulo}</h3>
            <p className="text-gray-600">{serv.desc}</p>
          </div>
        ))}
      </section>
    </main>
  )
}
